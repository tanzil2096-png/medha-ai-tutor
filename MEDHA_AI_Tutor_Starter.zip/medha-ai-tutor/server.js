import express from "express";
import cors from "cors";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = process.env.PORT || 10000;
const API_KEY = process.env.GEMINI_API_KEY;
const MODEL = process.env.GEMINI_MODEL || "gemini-2.5-flash";

if (!API_KEY) {
  console.error("Missing GEMINI_API_KEY environment variable.");
  process.exit(1);
}

app.use(helmet({ crossOriginResourcePolicy: { policy: "cross-origin" } }));

// For initial CodePen testing this allows all origins.
// Before public launch, set ALLOWED_ORIGIN to your app's exact HTTPS origin.
const allowedOrigin = process.env.ALLOWED_ORIGIN || "*";
app.use(cors({
  origin: allowedOrigin === "*" ? "*" : allowedOrigin.split(",").map(x => x.trim()),
  methods: ["GET", "POST", "OPTIONS"],
  allowedHeaders: ["Content-Type"]
}));

app.use(express.json({ limit: "8mb" }));

app.use("/api/", rateLimit({
  windowMs: 60 *  1000,
  limit: 20,
  standardHeaders: "draft-7",
  legacyHeaders: false,
  message: { error: "অনেকগুলো প্রশ্ন করা হয়েছে। এক মিনিট পরে আবার চেষ্টা করো।" }
}));

app.get("/", (_req, res) => {
  res.json({ name: "MEDHA AI Tutor API", status: "ok", model: MODEL });
});

app.post("/api/chat", async (req, res) => {
  try {
    const { message, grade = "নির্দিষ্ট নয়", language = "auto", history = [], image = null } = req.body || {};

    if (typeof message !== "string" || (!message.trim() && !image)) {
      return res.status(400).json({ error: "প্রশ্ন লিখো অথবা একটি ছবি দাও।" });
    }
    if (message.length > 4000) {
      return res.status(400).json({ error: "প্রশ্নটি ৪০০০ অক্ষরের মধ্যে রাখো।" });
    }

    const safeHistory = Array.isArray(history) ? history.slice(-10).map(item => ({
      role: item.role === "model" ? "model" : "user",
      parts: [{ text: String(item.text || "").slice(0, 3000) }]
    })).filter(item => item.parts[0].text.trim()) : [];

    const currentParts = [{ text: `শিক্ষার্থীর বর্তমান প্রশ্ন:\n${message.trim() || "ছবিটি দেখে প্রশ্নটি সমাধান করো।"}` }];

    if (image) {
      if (!["image/jpeg", "image/png", "image/webp"].includes(image.mimeType)) {
        return res.status(400).json({ error: "শুধু JPG, PNG অথবা WEBP ছবি দেওয়া যাবে।" });
      }
      if (typeof image.data !== "string" || image.data.length > 6_000_000) {
        return res.status(400).json({ error: "ছবিটি অনেক বড়। ৪ MB-এর ছোট ছবি ব্যবহার করো।" });
      }
      currentParts.push({
        inlineData: {
          mimeType: image.mimeType,
          data: image.data
        }
      });
    }

    const contents = [
      ...safeHistory,
      { role: "user", parts: currentParts }
    ];

    const systemText = `
তুমি MEDHA AI-এর একজন বন্ধুসুলভ, ধৈর্যশীল ও নির্ভুল শিক্ষক।
শিক্ষার্থীর শ্রেণি/ক্লাস: ${String(grade).slice(0, 40)}।
উত্তরের ভাষা: ${language === "bn" ? "বাংলা" : language === "en" ? "ইংরেজি" : "শিক্ষার্থীর প্রশ্নের ভাষা অনুসরণ করো"}।

নিয়ম:
1. শিক্ষার্থীর শ্রেণি অনুযায়ী সহজ ভাষায় বোঝাও।
2. গণিতের ক্ষেত্রে ধাপে ধাপে সমাধান দেখাও এবং শেষে উত্তর যাচাই করো।
3. ছবি থাকলে ছবির লেখা/অঙ্ক মনোযোগ দিয়ে পড়ো। অস্পষ্ট হলে অনুমান না করে পরিষ্কার ছবি চাইবে।
4. অজানা তথ্য বানিয়ে বলবে না; নিশ্চিত না হলে তা জানাবে।
5. প্রয়োজন হলে ছোট উদাহরণ দেবে এবং শেষে ১টি অনুশীলনী প্রশ্ন দিতে পারো।
6. উত্তর বাংলায় চাইলে প্রাঞ্জল বাংলা, ইংরেজি চাইলে সহজ ইংরেজি ব্যবহার করবে।
7. বিপজ্জনক বা অনুপযুক্ত অনুরোধে নিরাপদভাবে না বলবে।
8. উত্তরটি পরিষ্কার অনুচ্ছেদ ও তালিকায় দেবে।
`;

    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/${MODEL}:generateContent?key=${API_KEY}`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          systemInstruction: { parts: [{ text: systemText }] },
          contents,
          generationConfig: {
            temperature: 0.5,
            maxOutputTokens: 1200
          }
        })
      }
    );

    const data = await response.json();

    if (!response.ok) {
      console.error("Gemini API error:", data);
      const msg = data?.error?.message || "AI সার্ভিসে সমস্যা হয়েছে।";
      return res.status(response.status).json({ error: msg });
    }

    const answer = data?.candidates?.[0]?.content?.parts
      ?.map(part => part.text || "")
      .join("\n")
      .trim();

    if (!answer) {
      return res.status(502).json({ error: "AI উত্তর দিতে পারেনি। অন্যভাবে প্রশ্ন করো।" });
    }

    res.json({ answer, model: MODEL });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "সার্ভারে সমস্যা হয়েছে। কিছুক্ষণ পরে আবার চেষ্টা করো।" });
  }
});

app.listen(PORT, "0.0.0.0", () => {
  console.log(`MEDHA AI Tutor API listening on ${PORT}`);
});
