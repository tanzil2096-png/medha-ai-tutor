# MEDHA AI Tutor — Setup (বাংলা)

## কী আছে
- Gemini AI chat (বাংলা/English)
- শ্রেণি অনুযায়ী ব্যাখ্যা
- গণিত ধাপে ধাপে সমাধান
- JPG/PNG/WEBP ছবি দিয়ে প্রশ্ন
- Browser speech-to-text এবং text-to-speech
- Local device-এ chat history (localStorage)
- Express backend, API key server-side, basic rate limit

## ১) Gemini API key নাও
1. https://aistudio.google.com/app/apikey খোলো।
2. Google account দিয়ে লগইন করে API key তৈরি করো।
3. Key কাউকে দেবে না এবং CodePen HTML/JS-এ বসাবে না।

Gemini pricing/limits: https://ai.google.dev/gemini-api/docs/pricing

## ২) Backend deploy (Render)
1. এই ZIP GitHub repository-তে upload করো।
2. Render-এ New → Web Service → ওই repository connect করো।
3. Root Directory ফাঁকা রাখো (যদি server.js root-এ থাকে)।
4. Build Command: `npm install`
5. Start Command: `npm start`
6. Environment Variables যোগ করো:
   - GEMINI_API_KEY = তোমার key
   - GEMINI_MODEL = gemini-2.5-flash
   - ALLOWED_ORIGIN = * (শুধু প্রাথমিক পরীক্ষা; প্রকাশের আগে নিজের origin দাও)
7. Deploy শেষ হলে Render URL কপি করো। যেমন `https://medha-api.onrender.com`
8. ব্রাউজারে ওই URL খুলে `{"name":"MEDHA AI Tutor API","status":"ok",...}` দেখো।

Render free web service নিষ্ক্রিয় থাকলে sleep করে; প্রথম request-এ জাগতে সময় লাগতে পারে। Production অ্যাপের জন্য নির্ভরযোগ্য paid hosting বিবেচনা করো।

## ৩) CodePen-এ Frontend বসাও
1. CodePen-এ নতুন Pen তৈরি করো।
2. `public/index.html`-এর সম্পূর্ণ কোড HTML panel-এ paste করো (CSS ও JS একই ফাইলে আছে)।
3. HTML-এর একদম নিচের JavaScript-এ এই লাইনটি খুঁজে বের করো:
   `const API_URL = "https://YOUR-BACKEND-NAME.onrender.com/api/chat";`
4. নিজের Render URL বসাও, যেমন:
   `const API_URL = "https://medha-api.onrender.com/api/chat";`
5. Save করে Preview-তে পরীক্ষা করো।

## ৪) Android WebView
- WebView-তে Internet permission থাকতে হবে।
- HTTPS Backend URL ব্যবহার করো।
- Image picker-এর জন্য WebChromeClient.onShowFileChooser দরকার।
- ভয়েসের জন্য Android RECORD_AUDIO runtime permission এবং WebChromeClient.onPermissionRequest দরকার হতে পারে।
- সব Android System WebView-তে Web Speech API সমর্থিত নয়। কাজ না করলে native Android SpeechRecognizer এবং TextToSpeech bridge যোগ করতে হবে।
- WebView JavaScript চালু থাকতে হবে।
- Android app-এ File chooser না থাকলে ছবি বাছাইয়ের বাটন কাজ করবে না।

### ন্যূনতম AndroidManifest permission
`<uses-permission android:name="android.permission.INTERNET" />`
`<uses-permission android:name="android.permission.RECORD_AUDIO" />`

`RECORD_AUDIO` ব্যবহার করার আগে Android runtime permission চাইবে। শুধু Manifest-এ দিলেই যথেষ্ট নয়।

## নিরাপত্তা
- API key কখনো frontend-এ রাখবে না।
- Public launch-এর আগে `ALLOWED_ORIGIN`-এ নিজের app/site origin নির্দিষ্ট করো।
- IP-based rate limit এখন 20 request/minute; নিজের ব্যবহার অনুযায়ী বদলাও।
- History আপাতত ঐ ডিভাইসের localStorage-এ থাকে; অন্য ডিভাইসে sync হয় না।
- Google-এর free tier, quota ও model availability বদলাতে পারে। Usage dashboard দেখবে।
- Gemini free tier-এ পাঠানো তথ্য Google-এর product improvement-এ ব্যবহৃত হতে পারে; শিক্ষার্থীদের ব্যক্তিগত/সংবেদনশীল তথ্য পাঠাতে দিও না।
